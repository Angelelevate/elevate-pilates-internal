import { Router } from 'express'
import { FieldValue } from 'firebase-admin/firestore'
import { requireAuth, requireRole } from '../middleware/authMiddleware.js'
import { requireNoForcedPasswordChange } from '../middleware/mustChangePasswordMiddleware.js'
import { getVideoSignedUrl } from '../services/storage.js'
import { getDb } from '../utils/firestoreDb.js'
import { serializeDoc, serializeValue } from '../utils/serialize.js'

export const traineeRouter = Router()

traineeRouter.use(
  requireAuth,
  requireRole('trainee'),
  requireNoForcedPasswordChange,
)

function dbRequired() {
  const db = getDb()
  if (!db) {
    const err = new Error('Database not configured')
    err.status = 503
    throw err
  }
  return db
}

function progressDocId(traineeId, lessonId) {
  return `${traineeId}_${lessonId}`
}

async function loadPublishedLessonsForCourse(db, courseId) {
  const snap = await db.collection('lessons').where('courseId', '==', courseId).get()
  return snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .filter((l) => l.status === 'published')
}

async function loadPublishedModulesForCourse(db, courseId) {
  const snap = await db.collection('modules').where('courseId', '==', courseId).get()
  return snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .filter((m) => m.status === 'published')
    .sort((a, b) => (a.order || 0) - (b.order || 0))
}

/** Batched reads — avoids one round-trip per lesson (was the main dashboard slowdown). */
async function loadLessonProgressMap(db, traineeId, lessonIds) {
  const uniq = [...new Set(lessonIds.filter(Boolean))]
  const map = new Map()
  if (uniq.length === 0) return map
  const chunkSize = 10
  for (let i = 0; i < uniq.length; i += chunkSize) {
    const chunk = uniq.slice(i, i + chunkSize)
    const refs = chunk.map((lid) =>
      db.collection('lessonProgress').doc(progressDocId(traineeId, lid)),
    )
    const snaps = await db.getAll(...refs)
    for (let j = 0; j < chunk.length; j += 1) {
      const doc = snaps[j]
      if (doc.exists) map.set(chunk[j], { id: doc.id, ...doc.data() })
    }
  }
  return map
}

function isLessonCompleted(progress) {
  return progress?.status === 'completed'
}

/** Partial credit for in-progress video lessons (dashboard / module bars). */
function videoLessonProgressWeight(lesson, prog) {
  if (lesson.type !== 'video') return null
  if (!prog) return 0
  if (prog.status === 'completed') return 1
  const vp = prog.videoProgress
  if (!vp) return 0
  const pct = Number(vp.percentWatched)
  if (Number.isFinite(pct) && pct > 0) return Math.min(1, pct / 100)
  const dur = Number(lesson.content?.durationSeconds)
  const mr = Number(vp.maxReached)
  if (Number.isFinite(dur) && dur > 0 && Number.isFinite(mr) && mr > 0) {
    return Math.min(1, mr / dur)
  }
  return 0
}

function lessonProgressWeight(lesson, prog) {
  if (!prog) return 0
  if (isLessonCompleted(prog)) return 1
  const vw = videoLessonProgressWeight(lesson, prog)
  if (vw !== null) return vw
  return 0
}

function sumLessonWeights(lessons, progressByLessonId) {
  let sum = 0
  for (const l of lessons) {
    sum += lessonProgressWeight(l, progressByLessonId.get(l.id) ?? null)
  }
  return sum
}

function moduleCompletionState(mod, lessons, progressByLessonId) {
  const criteria = mod.completionCriteria || {}
  const needExam = Boolean(criteria.examPassed)
  const publishedLessons = lessons.filter((l) => l.status === 'published')
  let allDone = true
  for (const l of publishedLessons) {
    const p = progressByLessonId.get(l.id) ?? null
    if (!isLessonCompleted(p)) {
      allDone = false
      break
    }
  }
  let examOk = true
  if (needExam) {
    const examLesson = publishedLessons.find((l) => l.type === 'exam')
    if (examLesson) {
      const p = progressByLessonId.get(examLesson.id) ?? null
      examOk = isLessonCompleted(p)
    } else {
      examOk = true
    }
  }
  const completed = allDone && examOk
  let status = 'in_progress'
  if (completed) status = 'completed'
  return { completed, status, allDone, examOk }
}

async function assertEnrollment(db, traineeId, courseId) {
  const snap = await db
    .collection('enrollments')
    .where('traineeId', '==', traineeId)
    .get()
  const active = snap.docs
    .map((d) => ({ id: d.id, ...d.data() }))
    .find((e) => e.courseId === courseId && e.status === 'active')
  if (!active) {
    const err = new Error('Not enrolled in this course')
    err.status = 403
    throw err
  }
  const course = await db.collection('courses').doc(courseId).get()
  if (!course.exists || course.data().status !== 'published') {
    const err = new Error('Course is not available')
    err.status = 403
    throw err
  }
  return active
}

function computeModuleUnlock(modules, lessonsByModuleId, progressByLessonId) {
  const states = []
  for (let i = 0; i < modules.length; i += 1) {
    const mod = modules[i]
    const lessons = lessonsByModuleId.get(mod.id) || []
    const prev = i === 0 ? null : states[i - 1]
    const unlocked = i === 0 || (prev && prev.runtimeCompleted)
    const { completed, status, allDone, examOk } = moduleCompletionState(
      mod,
      lessons,
      progressByLessonId,
    )
    const runtimeCompleted = completed
    states.push({
      module: mod,
      lessons,
      unlocked,
      status: unlocked ? (completed ? 'completed' : status) : 'locked',
      completedLessonCount: countCompletedLessons(lessons, progressByLessonId),
      lessonCount: lessons.filter((l) => l.status === 'published').length,
      runtimeCompleted,
      prerequisiteTitle: i > 0 ? modules[i - 1].title : null,
      allDone,
      examOk,
    })
  }
  return states
}

function countCompletedLessons(lessons, progressByLessonId) {
  let n = 0
  for (const l of lessons.filter((x) => x.status === 'published')) {
    const p = progressByLessonId.get(l.id) ?? null
    if (isLessonCompleted(p)) n += 1
  }
  return n
}

traineeRouter.get('/enrollments', async (req, res, next) => {
  try {
    const db = dbRequired()
    const snap = await db.collection('enrollments').where('traineeId', '==', req.user.uid).get()
    const rows = []
    for (const d of snap.docs) {
      const en = serializeDoc(d)
      const c = await db.collection('courses').doc(en.courseId).get()
      rows.push({
        ...en,
        course: c.exists ? serializeDoc(c) : null,
      })
    }
    res.json(rows)
  } catch (e) {
    next(e)
  }
})

traineeRouter.get('/courses', async (req, res, next) => {
  try {
    const db = dbRequired()
    const snap = await db.collection('enrollments').where('traineeId', '==', req.user.uid).get()
    const out = []
    for (const d of snap.docs) {
      const enData = d.data()
      if (enData.status !== 'active') continue
      const courseDoc = await db.collection('courses').doc(enData.courseId).get()
      if (!courseDoc.exists || courseDoc.data().status !== 'published') continue
      const courseId = enData.courseId
      const modules = await loadPublishedModulesForCourse(db, courseId)
      const allLessons = await loadPublishedLessonsForCourse(db, courseId)
      const lessonsByModule = new Map()
      for (const l of allLessons) {
        const arr = lessonsByModule.get(l.moduleId) || []
        arr.push(l)
        lessonsByModule.set(l.moduleId, arr)
      }
      const progressByLessonId = await loadLessonProgressMap(
        db,
        req.user.uid,
        allLessons.map((l) => l.id),
      )
      const states = computeModuleUnlock(modules, lessonsByModule, progressByLessonId)
      const totalLessons = allLessons.length
      let completedLessons = 0
      for (const l of allLessons) {
        const p = progressByLessonId.get(l.id)
        if (isLessonCompleted(p)) completedLessons += 1
      }
      const weightedSum = sumLessonWeights(allLessons, progressByLessonId)
      const courseProgressPercent =
        totalLessons === 0 ? 0 : Math.round((weightedSum / totalLessons) * 100)
      out.push({
        enrollment: serializeDoc(d),
        course: serializeDoc(courseDoc),
        courseProgressPercent,
        completedLessons,
        totalLessons,
        modules: states.map((s) => {
          const w = sumLessonWeights(
            s.lessons.filter((l) => l.status === 'published'),
            progressByLessonId,
          )
          return {
            id: s.module.id,
            title: s.module.title,
            description: s.module.description,
            order: s.module.order,
            status: s.status,
            unlocked: s.unlocked,
            prerequisiteTitle: s.prerequisiteTitle,
            lessonCount: s.lessonCount,
            completedLessonCount: s.completedLessonCount,
            progressPercent:
              s.lessonCount === 0 ? 0 : Math.round((w / s.lessonCount) * 100),
          }
        }),
      })
    }
    res.json(out)
  } catch (e) {
    next(e)
  }
})

traineeRouter.get('/courses/:courseId', async (req, res, next) => {
  try {
    const db = dbRequired()
    const { courseId } = req.params
    await assertEnrollment(db, req.user.uid, courseId)
    const courseDoc = await db.collection('courses').doc(courseId).get()
    const modules = await loadPublishedModulesForCourse(db, courseId)
    const allLessons = await loadPublishedLessonsForCourse(db, courseId)
    const lessonsByModule = new Map()
    for (const l of allLessons) {
      const arr = lessonsByModule.get(l.moduleId) || []
      arr.push(l)
      lessonsByModule.set(l.moduleId, arr)
    }
    const progressByLessonId = await loadLessonProgressMap(
      db,
      req.user.uid,
      allLessons.map((l) => l.id),
    )
    const states = computeModuleUnlock(modules, lessonsByModule, progressByLessonId)
    const totalLessons = allLessons.length
    let completedLessons = 0
    for (const l of allLessons) {
      const p = progressByLessonId.get(l.id)
      if (isLessonCompleted(p)) completedLessons += 1
    }
    const weightedSum = sumLessonWeights(allLessons, progressByLessonId)
    res.json({
      course: serializeDoc(courseDoc),
      courseProgressPercent:
        totalLessons === 0 ? 0 : Math.round((weightedSum / totalLessons) * 100),
      modules: states.map((s) => {
        const w = sumLessonWeights(
          s.lessons.filter((l) => l.status === 'published'),
          progressByLessonId,
        )
        return {
          id: s.module.id,
          title: s.module.title,
          description: s.module.description,
          order: s.module.order,
          status: s.status,
          unlocked: s.unlocked,
          prerequisiteTitle: s.prerequisiteTitle,
          lessonCount: s.lessonCount,
          completedLessonCount: s.completedLessonCount,
          progressPercent:
            s.lessonCount === 0 ? 0 : Math.round((w / s.lessonCount) * 100),
        }
      }),
    })
  } catch (e) {
    next(e)
  }
})

traineeRouter.get(
  '/courses/:courseId/modules/:moduleId',
  async (req, res, next) => {
    try {
      const db = dbRequired()
      const { courseId, moduleId } = req.params
      await assertEnrollment(db, req.user.uid, courseId)
      const modDoc = await db.collection('modules').doc(moduleId).get()
      if (!modDoc.exists || modDoc.data().courseId !== courseId) {
        const err = new Error('Module not found')
        err.status = 404
        throw err
      }
      const mod = { id: modDoc.id, ...modDoc.data() }
      if (mod.status !== 'published') {
        const err = new Error('Module is not available')
        err.status = 403
        throw err
      }
      const modules = await loadPublishedModulesForCourse(db, courseId)
      const allLessons = await loadPublishedLessonsForCourse(db, courseId)
      const lessonsByModule = new Map()
      for (const l of allLessons) {
        const arr = lessonsByModule.get(l.moduleId) || []
        arr.push(l)
        lessonsByModule.set(l.moduleId, arr)
      }
      const progressByLessonId = await loadLessonProgressMap(
        db,
        req.user.uid,
        allLessons.map((l) => l.id),
      )
      const states = computeModuleUnlock(modules, lessonsByModule, progressByLessonId)
      const state = states.find((s) => s.module.id === moduleId)
      if (!state || !state.unlocked) {
        const err = new Error('Module is locked')
        err.status = 403
        throw err
      }
      const lessons = (lessonsByModule.get(moduleId) || [])
        .filter((l) => l.status === 'published')
        .sort((a, b) => (a.order || 0) - (b.order || 0))
      const lessonRows = []
      for (const l of lessons) {
        const p = progressByLessonId.get(l.id) ?? null
        lessonRows.push({
          id: l.id,
          title: l.title,
          type: l.type,
          order: l.order,
          status: p?.status || 'not_started',
          score: p?.score ?? null,
          attemptCount: p?.attemptCount ?? 0,
        })
      }
      const firstIncomplete = lessonRows.find((r) => r.status !== 'completed')
      res.json({
        module: serializeDoc(modDoc),
        moduleStatus: state.status,
        lessons: lessonRows,
        continueLessonId: firstIncomplete?.id ?? lessonRows[0]?.id ?? null,
      })
    } catch (e) {
      next(e)
    }
  },
)

traineeRouter.get(
  '/courses/:courseId/modules/:moduleId/lessons/:lessonId',
  async (req, res, next) => {
    try {
      const db = dbRequired()
      const { courseId, moduleId, lessonId } = req.params
      await assertEnrollment(db, req.user.uid, courseId)
      const modDoc = await db.collection('modules').doc(moduleId).get()
      if (!modDoc.exists || modDoc.data().courseId !== courseId) {
        const err = new Error('Module not found')
        err.status = 404
        throw err
      }
      if (modDoc.data().status !== 'published') {
        const err = new Error('Module is not available')
        err.status = 403
        throw err
      }
      const modules = await loadPublishedModulesForCourse(db, courseId)
      const allLessons = await loadPublishedLessonsForCourse(db, courseId)
      const lessonsByModule = new Map()
      for (const l of allLessons) {
        const arr = lessonsByModule.get(l.moduleId) || []
        arr.push(l)
        lessonsByModule.set(l.moduleId, arr)
      }
      const progressByLessonId = await loadLessonProgressMap(
        db,
        req.user.uid,
        allLessons.map((l) => l.id),
      )
      const states = computeModuleUnlock(modules, lessonsByModule, progressByLessonId)
      const state = states.find((s) => s.module.id === moduleId)
      if (!state || !state.unlocked) {
        const err = new Error('Module is locked')
        err.status = 403
        throw err
      }
      const lessonDoc = await db.collection('lessons').doc(lessonId).get()
      if (!lessonDoc.exists || lessonDoc.data().moduleId !== moduleId) {
        const err = new Error('Lesson not found')
        err.status = 404
        throw err
      }
      if (lessonDoc.data().status !== 'published') {
        const err = new Error('Lesson is not available')
        err.status = 403
        throw err
      }
      const lesson = serializeDoc(lessonDoc)
      const progress = progressByLessonId.get(lessonId) ?? null
      res.json({ lesson, progress })
    } catch (e) {
      next(e)
    }
  },
)

traineeRouter.post(
  '/progress/lessons/:lessonId/complete',
  async (req, res, next) => {
    try {
      const db = dbRequired()
      const { lessonId } = req.params
      const lessonDoc = await db.collection('lessons').doc(lessonId).get()
      if (!lessonDoc.exists) {
        const err = new Error('Lesson not found')
        err.status = 404
        throw err
      }
      const lesson = lessonDoc.data()
      const { courseId } = lesson
      await assertEnrollment(db, req.user.uid, courseId)
      if (lesson.status !== 'published') {
        const err = new Error('Lesson is not available')
        err.status = 403
        throw err
      }
      if (lesson.type === 'reading' || lesson.type === 'quiz') {
        // ok
      } else if (lesson.type === 'exam') {
        const err = new Error('Complete the exam via the quiz engine when available')
        err.status = 400
        throw err
      } else if (lesson.type === 'video') {
        const err = new Error('Use video-progress to complete video lessons')
        err.status = 400
        throw err
      }
      const id = progressDocId(req.user.uid, lessonId)
      const ref = db.collection('lessonProgress').doc(id)
      await ref.set(
        {
          lessonId,
          moduleId: lesson.moduleId,
          courseId,
          traineeId: req.user.uid,
          status: 'completed',
          lessonType: lesson.type,
          videoProgress: null,
          completedAt: FieldValue.serverTimestamp(),
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true },
      )
      res.json(serializeDoc(await ref.get()))
    } catch (e) {
      next(e)
    }
  },
)

traineeRouter.post(
  '/progress/lessons/:lessonId/video-progress',
  async (req, res, next) => {
    try {
      const db = dbRequired()
      const { lessonId } = req.params
      const lessonDoc = await db.collection('lessons').doc(lessonId).get()
      if (!lessonDoc.exists) {
        const err = new Error('Lesson not found')
        err.status = 404
        throw err
      }
      const lesson = lessonDoc.data()
      if (lesson.type !== 'video') {
        const err = new Error('Not a video lesson')
        err.status = 400
        throw err
      }
      const { courseId } = lesson
      await assertEnrollment(db, req.user.uid, courseId)
      if (lesson.status !== 'published') {
        const err = new Error('Lesson is not available')
        err.status = 403
        throw err
      }
      const lastPosition = Number(req.body?.lastPosition) || 0
      const maxReached = Number(req.body?.maxReached) || 0
      const percentWatched = Number(req.body?.percentWatched) || 0
      const watchedToEnd = Boolean(req.body?.watchedToEnd)
      const id = progressDocId(req.user.uid, lessonId)
      const ref = db.collection('lessonProgress').doc(id)
      const existingSnap = await ref.get()
      const createdAt = existingSnap.exists
        ? existingSnap.data().createdAt
        : FieldValue.serverTimestamp()
      const completed = percentWatched >= 90 || watchedToEnd
      const storedPercent = completed ? Math.max(percentWatched, 100) : percentWatched
      const patch = {
        lessonId,
        moduleId: lesson.moduleId,
        courseId,
        traineeId: req.user.uid,
        status: completed ? 'completed' : 'in_progress',
        lessonType: 'video',
        videoProgress: {
          lastPosition,
          maxReached: watchedToEnd ? Math.max(maxReached, lastPosition) : maxReached,
          percentWatched: storedPercent,
        },
        updatedAt: FieldValue.serverTimestamp(),
        createdAt,
      }
      if (completed) {
        patch.completedAt = FieldValue.serverTimestamp()
      } else {
        patch.completedAt = FieldValue.delete()
      }
      await ref.set(patch, { merge: true })
      const saved = await ref.get()
      res.json(serializeDoc(saved))
    } catch (e) {
      next(e)
    }
  },
)

traineeRouter.get('/progress/courses/:courseId', async (req, res, next) => {
  try {
    const db = dbRequired()
    const { courseId } = req.params
    await assertEnrollment(db, req.user.uid, courseId)
    const lessons = await loadPublishedLessonsForCourse(db, courseId)
    const progressByLessonId = await loadLessonProgressMap(
      db,
      req.user.uid,
      lessons.map((l) => l.id),
    )
    const rows = []
    for (const l of lessons) {
      const p = progressByLessonId.get(l.id)
      if (p) rows.push(serializeValue(p))
    }
    res.json(rows)
  } catch (e) {
    next(e)
  }
})

traineeRouter.get('/lessons/:lessonId/video-url', async (req, res, next) => {
  try {
    const db = dbRequired()
    const lessonDoc = await db.collection('lessons').doc(req.params.lessonId).get()
    if (!lessonDoc.exists) {
      const err = new Error('Lesson not found')
      err.status = 404
      throw err
    }
    const lesson = lessonDoc.data()
    if (lesson.type !== 'video') {
      const err = new Error('Not a video lesson')
      err.status = 400
      throw err
    }
    await assertEnrollment(db, req.user.uid, lesson.courseId)
    if (lesson.status !== 'published') {
      const err = new Error('Lesson is not available')
      err.status = 403
      throw err
    }
    const path = lesson.content?.storagePath
    if (!path) {
      const err = new Error('Video not uploaded')
      err.status = 404
      throw err
    }
    const url = await getVideoSignedUrl(path)
    res.json({ downloadUrl: url })
  } catch (e) {
    next(e)
  }
})
